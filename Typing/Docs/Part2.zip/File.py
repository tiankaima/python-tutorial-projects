"""
file.py - Class for file.
"""


class File:
    def __init__(self, source_path=""):
        """
        Instance initialization settings.

        :param source_path: The path where the file is stored. This parameter is a string representing the path to the file.

        :var self.name: The name of the file. This is a string representing the file name.
        :var self.path: The path in a standard format. This is a string representing the standardized path to the file.
        """

    def transfer(self, target_path=""):
        """
        Transfer the file.

        :param target_path: The path where the file is to be transferred. This parameter is a string representing the path to the target directory.
        :return: The new path to the file after transfer.
        """

    def __str__(self):
        """
        Rewrite the print function.

        :return: A string representing the name and path of the file.
        """
"""
folder.py - Class for folder.
"""


class Folder:
    def __init__(self, source_path=""):
        """
        Instance initialization settings.

        :param source_path: The path of the folder. This is a string representing the path to the folder.

        :var self.name: The name of the folder. This is a string representing the name of the folder.
        :var self.path: The path in a standard format. This is a string representing the standardized path to the folder.
        """

    def unpack(self, target_path=""):
        """
        Unpack the folder.

        :param target_path: The path where the files in the folder will be unpacked. This is a string representing the path to the target directory.
        """

    def __str__(self):
        """
        Rewrite the print function.

        :return: A string representing the name and path of the folder.
        """